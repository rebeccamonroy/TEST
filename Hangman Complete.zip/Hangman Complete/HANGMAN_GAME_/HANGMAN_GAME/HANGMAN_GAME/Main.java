public class Main {

    public static void main(String[] args) {

        Hangman hg = new Hangman();
        hg.initGame();
        hg.play();
        hg.showResult();

    }

} 