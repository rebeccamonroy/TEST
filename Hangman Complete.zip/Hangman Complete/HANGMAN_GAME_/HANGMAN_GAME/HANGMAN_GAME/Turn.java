public class Turn {

    public Board board;
    public Player player;
    public Player player2;

    public Turn(Player player, Board board) {
        this.board = board;
        this.player = player;
    }

    public void execute() {
        do {
            char[] letter = Input.getChar("Type a letter: ");// otro lado para validar
            for(int i=0; i< board.getSecretWord().length();i++) {
                board.hangmanIcon();
                if (board.wasGuessed()) {
                    board.printBoard();
                    if (board.tryHintCharacter(letter[i])) {
                        System.out.println("Correct letter!!\n");
                    } else {
                        System.out.println("Try again:( \n");
                    }
                } else {
                    askPlayerSecretWord();
                    askPlayerAttempts();
                    board.printBoard();
                }
            }
        }while (board.otherTurn()) ;
    }

    public void askPlayerSecretWord() {
        String secret = Input.getString("Type a secret word for the player: ");
    }

    public void askPlayerAttempts() {
        int attempts = Input.getInteger("Type number of attempts: ");
    }

}
